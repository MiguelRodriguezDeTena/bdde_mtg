from gold import gold_transform
from silver import silver_transform
from bronze import api_call